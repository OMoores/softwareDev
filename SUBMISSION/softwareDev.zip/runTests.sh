java -jar lib/junit-platform-console-standalone-1.9.1.jar -cp ./bin --scan-classpath
$SHELL