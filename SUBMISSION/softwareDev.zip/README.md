To run tests unzip the cardTest.zip file, navigate to the unzipped file (so you are in the folder softwareDev) and enter 
java -jar lib/junit-platform-console-standalone-1.9.1.jar -cp ./bin --scan-classpath
into the command line

OR

if you have gitbash installed/are able to run .sh files run the runTests.sh script